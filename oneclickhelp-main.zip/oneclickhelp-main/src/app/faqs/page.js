import Footer from "@/components/footer/footer";
import Header from "@/components/header/header";
import FAQ from "@/components/static/FAQs";

export default function Home() {
  return (
    <>
       <Header />
        <FAQ />
       <Footer />
    </>
       
  );
}
