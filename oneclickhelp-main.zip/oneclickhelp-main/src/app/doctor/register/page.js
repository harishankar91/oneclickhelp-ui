import Register from "@/components/doctor/Auth/Register";

export default function Home() {
  return (
       <Register />
  );
}
