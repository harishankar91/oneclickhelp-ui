import Footer from "@/components/footer/footer";
import Header from "@/components/header/header";
import TermsOfUse from "@/components/static/TermsOfUse";

export default function Home() {
  return (
    <>
       <Header />
        <TermsOfUse />
       <Footer />
    </>
       
  );
}
