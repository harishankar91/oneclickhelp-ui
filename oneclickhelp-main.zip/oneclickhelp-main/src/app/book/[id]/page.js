import Bookapintment from "@/components/bookapointment/Bookapointment";
import Footer from "@/components/footer/footer";
import Header from "@/components/header/header";

export default function bookapointment() {
  return (
    <>
       <Header />
       <Bookapintment />
       <Footer />
    </>
       
  );
}